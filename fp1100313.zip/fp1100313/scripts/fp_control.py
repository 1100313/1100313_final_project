#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

def callback(data):
    regions = {
        'right':  min(min(data.ranges[0:143]), 10),
        'front':  min(min(data.ranges[288:431]), 10),
        'left':   min(min(data.ranges[576:719]), 10),
    }
    take_action(regions)

def take_action(regions):
    msg = Twist()
    linear_x = 0
    angular_z = 0

    state_description = ''

    if regions['front'] < 0.45:
        state_description = 'case 1 - front'
        linear_x = 0
        angular_z = -1
    elif regions['left'] < 0.3:
        state_description = 'case 2 - left'
        linear_x = 0
        angular_z = -1
    elif regions['right'] < 0.3:
        state_description = 'case 3 - right'
        linear_x = 0
        angular_z = 1
    else:
        state_description = 'case 4 - clear'
        linear_x = 0.55
        angular_z = 0
    
    rospy.loginfo(state_description)
    msg.linear.x = linear_x
    msg.angular.z = angular_z
    pub.publish(msg)

def main():
    global pub

    rospy.init_node('obstacle_avoidance')
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    sub = rospy.Subscriber('/scan', LaserScan, callback)

    rospy.spin()

if __name__ == '__main__':
    main()
